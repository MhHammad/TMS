package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.HomeMakerRepository;
import com.app.pojos.HomeMaker;

@Service
@Transactional
public class HomeMakerServiceImpl implements IHomeMakerService {
@Autowired
private HomeMakerRepository homeMaker;
	
	@Override
	public List<HomeMaker> getAllHomeMakers() {
		return homeMaker.findAll();
	}

	@Override
	public HomeMaker getHomeMakerById(int id) {
		return homeMaker.findById(id).orElseThrow(()-> new RuntimeException()) ;
	}

	@Override
	public String deleteHomeMakerById(int id) {
		String mg="Deletion not successful...!!!!";
		
		if(homeMaker.existsById(id))
		{
			homeMaker.deleteById(id);
			mg="HomeMaker with ID: "+id+" deleted successfully";
		}			
		return mg;
	}

	@Override
	public HomeMaker saveHomeMakerDetails(HomeMaker TransientHomeMaker) {
		
		return homeMaker.save(TransientHomeMaker);
	}

	@Override
	public HomeMaker updateHomeMakerDetails(HomeMaker detachedHomeMaker) {
		
		return homeMaker.save(detachedHomeMaker);
	}

}
