package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.HomeMakerRepository;
import com.app.pojos.HomeMaker;

import custom_exceptions.HomeMakerHandlingException;

@Service
@Transactional
public class HomeMakerServiceImpl implements IHomeMakerService {
	@Autowired
	private HomeMakerRepository homeMakerRepo;

	@Override
	public HomeMaker authenticateHomeMaker(String email, String pwd) {

		return homeMakerRepo.findByEmailAndPassword(email, pwd)
				.orElseThrow(() -> new HomeMakerHandlingException("Invalid Credentials"));
	}

	@Override
	public List<HomeMaker> getAllHomeMakers() {
		return homeMakerRepo.findAll();
	}

	@Override
	public HomeMaker getHomeMakerById(int id) {
		return homeMakerRepo.findById(id)
				.orElseThrow(() -> new HomeMakerHandlingException("HomeMaker does not exist!!!"));
	}

	@Override
	public String deleteHomeMakerById(int id) {
		String mg = "Deletion not successful...!!!!";

		if (homeMakerRepo.existsById(id)) {
			homeMakerRepo.deleteById(id);
			mg = "HomeMaker with ID: " + id + " deleted successfully";
		}
		return mg;
	}

	@Override
	public HomeMaker saveHomeMakerDetails(HomeMaker TransientHomeMaker) {

		return homeMakerRepo.save(TransientHomeMaker);
	}

	@Override
	public HomeMaker updateHomeMakerDetails(HomeMaker detachedHomeMaker) {

		return homeMakerRepo.save(detachedHomeMaker);
	}
}
