package com.app.service;

import java.util.List;

import com.app.pojos.Customer;

public interface ICustomerService {
	
	//to authenticate user as a: Customer
	Customer findByEmailAndPassword(String em, String pass);
	
//	Optional<Customer> authenticateCustomer(@Param("email") String email, @Param("password") String password);
	
	//to get all Customers
	List<Customer> getAllCustomers();

	//to get a Customer details by id
	Customer getCustById(int id);
	
	//to delete a Customer
	String deleteCustById(int id);
	
	//to save a Customer received as json object from frontend
	Customer saveCustDetails(Customer customer);
	
	//to update details of a Customer
	Customer updateCustDetails(Customer detachedCustomer);
}
