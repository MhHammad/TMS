package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.CustomerRepository;
import com.app.pojos.Customer;

import custom_exceptions.CustomerHandlingException;

@Service
@Transactional
public class CustomerServiceImpl implements ICustomerService {
	@Autowired
	private CustomerRepository Customer;
	
	//to authenticate user as a: Customer
	@Override
	public Customer findByEmailAndPassword(String em, String pass) {
		
		return Customer.findByEmailAndPassword(em, pass).
				orElseThrow(() -> new CustomerHandlingException("Invalid email or password"));
	}

	@Override
	public List<Customer> getAllCustomers() {
		return Customer.findAll();
	}

	@Override
	public Customer getCustById(int id) {
		return Customer.findById(id).orElseThrow(() -> new RuntimeException());
	}

	@Override
	public String deleteCustById(int id) {
		String mg = "Deletion not successful...!!!!";

		if (Customer.existsById(id)) {
			Customer.deleteById(id);
			mg = "Customer with ID: " + id + " deleted successfully";
		}
		return mg;
	}

	@Override
	public Customer saveCustDetails(Customer Cust) {

		return Customer.save(Cust);
	}

	@Override
	public Customer updateCustDetails(Customer detachedCust) {

		return Customer.save(detachedCust);
	}

}
