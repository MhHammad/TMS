package com.app.service;

import java.util.List;

import com.app.pojos.HomeMaker;

public interface IHomeMakerService {
	
	//to authenticate use as : HomeMaker
	HomeMaker authenticateHomeMaker(String email, String pwd);
	
	//to get all HomeMakers
	List<HomeMaker> getAllHomeMakers();

	//to get a HomeMaker details by id
	HomeMaker getHomeMakerById(int id);
	
	//to delete a HomeMaker
	String deleteHomeMakerById(int id);
	
	//to save a HomeMaker received as json object from frontend
	HomeMaker saveHomeMakerDetails(HomeMaker HomeMaker);
	
	//to update details of a HomeMaker
	HomeMaker updateHomeMakerDetails(HomeMaker detachedHomeMaker);
}
