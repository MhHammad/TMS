package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.AdminRepository;
import com.app.pojos.Admin;

import custom_exceptions.ResourceNotFoundException;

@Service
@Transactional
public class AdminServiceImpl implements IAdminService {

	@Autowired
	private AdminRepository adminRepo;

	@Override
	public Admin authenticateAdmin(String email, String pwd) {

		return adminRepo.findByEmailAndPassword(email, pwd)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid credentials..!!"));
	}

}
