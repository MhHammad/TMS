package com.app.service;

import com.app.pojos.Admin;

public interface IAdminService {
	
	//to authenticate use as : Admin
	Admin authenticateAdmin(String email, String pwd);	
}
