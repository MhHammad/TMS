package com.app.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.HomeMaker;

public interface HomeMakerRepository extends JpaRepository<HomeMaker, Integer> {

}
