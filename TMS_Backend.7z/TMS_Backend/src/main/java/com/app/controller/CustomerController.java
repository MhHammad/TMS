package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.Customer;
import com.app.service.ICustomerService;

@RestController
@RequestMapping("/api/customers")
@CrossOrigin
public class CustomerController {
	
	@Autowired
	private ICustomerService service;
	
	public CustomerController() {
		System.out.println("In ctor of "+ getClass());		
	}
	
	//to authenticate user as a: Customer
	@GetMapping("/login/{email}/{pwd}")
	public ResponseEntity<?> authenticateCustomer(@PathVariable String email, @PathVariable String pwd)
	{
		System.out.println("In Authenticate Customer: "+ email+" "+pwd);
		
		try {
			return ResponseEntity.ok(service.findByEmailAndPassword(email, pwd));
		} catch (RuntimeException e) {
			System.out.println("err in Authenticate Customer  " + e);
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}
	
	//req handling method to return list of all Customers
	@GetMapping
	public List<Customer> getAllCustomers()
	{
		System.out.println("In getAllCustomers() ");
		return service.getAllCustomers();	
	}
	
	//req handling method to return  Customer details by ID
	@GetMapping("{CustId}")
	public  Customer getCustById(@PathVariable int CustId)
	{
		return service.getCustById(CustId);			
	}
	
	//req handling method to delete a Customer by ID
	@DeleteMapping("{id}")
	public String deleteCustById(@PathVariable int id)
	{
		return service.deleteCustById(id);
	}
	
	//req handling method to save a Customer received as json object from front end 
	@PostMapping()
	public Customer saveCustomerDetails(@RequestBody Customer Cust)
	{
		return service.saveCustDetails(Cust);
	}
	
	//req handling method to update Customer details
	@PutMapping
	public Customer updateCustDetails(@RequestBody Customer Cust)
	{
		return service.updateCustDetails(Cust);
	}

}
