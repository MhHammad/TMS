package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.app.pojos.HomeMaker;
import com.app.service.IHomeMakerService;

@RestController
@RequestMapping("/api/homemakers")
@CrossOrigin
public class HomeMakerController {
	
	@Autowired
	private IHomeMakerService service;
	
	public HomeMakerController() {
		System.out.println("In ctor of "+ getClass());		
	}
	//req handling method to return list of all HomeMakers
	@GetMapping
	public List<HomeMaker> getAllHomeMakers()
	{
		System.out.println("In getAllHomeMakers() ");
		return service.getAllHomeMakers();	
	}
	
	//req handling method to return  HomeMaker details by ID
	@GetMapping("{HomeMakerId}")
	public  HomeMaker getHomeMakerById(@PathVariable int HomeMakerId)
	{
		return service.getHomeMakerById(HomeMakerId);			
	}
	
	//req handling method to delete a HomeMaker by ID
	@DeleteMapping("{id}")
	public String deleteHomeMakerById(@PathVariable int id)
	{
		return service.deleteHomeMakerById(id);
	}
	
	//req handling method to save a HomeMaker received as json object from front end 
	@PostMapping()
	public HomeMaker saveHomeMakerDetails(@RequestBody HomeMaker homeMaker)
	{
		return service.saveHomeMakerDetails(homeMaker);
	}
	
	//req handling method to update HomeMaker details
	@PutMapping
	public HomeMaker updateHomeMakerDetails(@RequestBody HomeMaker homeMaker)
	{
		System.out.println("ID: "+homeMaker.getId());
		return service.updateHomeMakerDetails(homeMaker);
	}

}
