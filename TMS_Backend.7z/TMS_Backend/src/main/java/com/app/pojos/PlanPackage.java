package com.app.pojos;

public enum PlanPackage {
	MINI, CLASSIC, JUMBO
}