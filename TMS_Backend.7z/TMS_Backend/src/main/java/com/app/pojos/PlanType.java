package com.app.pojos;

public enum PlanType {
	VEG, NON_VEG
}
