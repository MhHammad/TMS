package com.app.pojos;

public enum Weekday {
	
	SUNDAY,MONDAY,TUESDAY,WEDNESDAY,	THURSDAY,FRIDAY,SATURDAY

}
