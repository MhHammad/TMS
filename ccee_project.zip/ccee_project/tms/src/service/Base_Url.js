const base_url="http://localhost:7071"
export default base_url